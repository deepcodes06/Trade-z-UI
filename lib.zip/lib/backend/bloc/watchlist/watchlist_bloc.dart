import 'dart:async';
import 'dart:developer' as dev;

import 'package:flutter_bloc/flutter_bloc.dart';

import '../../models/stock_model.dart';
import '../../repositories/market_repository.dart';
import '../../models/watchlist_model.dart';
import '../../services/notification_service.dart';
import 'watchlist_event.dart';
import 'watchlist_state.dart';

class WatchlistBloc extends Bloc<WatchlistEvent, WatchlistState> {
  static const String _logName = 'WatchlistBloc';
  // 20s (not 15s) to leave more of Twelve Data's ~8-credits/minute free-tier
  // budget for other screens (Home, Stock Detail) polling at the same time.
  // MarketRepository's shared credit guard is the real safety net either
  // way - see _QuoteCache in market_repository.dart.
  static const Duration _refreshInterval = Duration(seconds: 20);

  final MarketRepository _repo;
  Timer? _refreshTimer;
  final Set<String> _notifiedSymbols = <String>{};

  WatchlistBloc({MarketRepository? repository})
      : _repo = repository ?? MarketRepository(),
        super(const WatchlistState()) {
    on<WatchlistsLoadRequested>(_onLoad);
    on<WatchlistCreateRequested>(_onCreate);
    on<WatchlistRenameRequested>(_onRename);
    on<WatchlistDeleteRequested>(_onDelete);
    on<WatchlistAddStockRequested>(_onAdd);
    on<WatchlistRemoveStockRequested>(_onRemove);
    on<WatchlistActiveStocksRequested>(_onFetchActive);
    on<WatchlistRefreshRequested>(_onRefresh);
    on<_WatchlistAutoTick>(_onAutoTick);
  }

  void _log(String msg) => dev.log(msg, name: _logName);

  void startAutoRefresh() {
    _refreshTimer?.cancel();
    _refreshTimer = Timer.periodic(_refreshInterval, (_) {
      if (isClosed) return;
      add(const _WatchlistAutoTick());
    });
    _log('auto-refresh started (${_refreshInterval.inSeconds}s)');
  }

  @override
  Future<void> close() {
    _refreshTimer?.cancel();
    return super.close();
  }

  void _maybeNotifyForBlowUp(List<StockModel> stocks) {
    for (final stock in stocks) {
      if (!stock.isBlowUpSignal || _notifiedSymbols.contains(stock.symbol)) continue;
      _notifiedSymbols.add(stock.symbol);
      unawaited(NotificationService.instance.showBlowUp(stock.symbol));
    }
  }

  Future<void> _onLoad(
      WatchlistsLoadRequested e, Emitter<WatchlistState> emit) async {
    _log('WatchlistsLoadRequested');
    emit(state.copyWith(status: WatchlistStatus.loading));
    const defaultSymbols = ['RELIANCE', 'TCS', 'HDFCBANK'];
    final defaultList = WatchlistModel(
      id: 'w_${DateTime.now().millisecondsSinceEpoch}',
      name: 'My Watchlist',
      symbols: defaultSymbols,
    );
    final active = await _repo.fetchStocks(defaultSymbols);
    _maybeNotifyForBlowUp(active);
    _log('default list active stocks: ${active.length}/${defaultSymbols.length}');
    emit(state.copyWith(
      status: WatchlistStatus.ready,
      lists: [defaultList],
      activeId: defaultList.id,
      activeStocks: active,
      isLive: _repo.isLive,
      lastUpdated: DateTime.now(),
    ));
    startAutoRefresh();
  }

  Future<void> _onCreate(
      WatchlistCreateRequested e, Emitter<WatchlistState> emit) async {
    if (state.lists.length >= WatchlistState.maxLists) {
      _log('max watchlists reached');
      emit(state.copyWith(error: 'Maximum ${WatchlistState.maxLists} watchlists reached'));
      return;
    }
    final newList = WatchlistModel(
      id: 'w_${DateTime.now().microsecondsSinceEpoch}',
      name: e.name.trim().isEmpty ? 'Watchlist ${state.lists.length + 1}' : e.name.trim(),
      symbols: const [],
    );
    emit(state.copyWith(
      lists: [...state.lists, newList],
      activeId: newList.id,
      activeStocks: const [],
      error: null,
    ));
  }

  Future<void> _onRename(
      WatchlistRenameRequested e, Emitter<WatchlistState> emit) async {
    final updated = state.lists
        .map((w) => w.id == e.id ? w.copyWith(name: e.name) : w)
        .toList();
    emit(state.copyWith(lists: updated));
  }

  Future<void> _onDelete(
      WatchlistDeleteRequested e, Emitter<WatchlistState> emit) async {
    final updated = state.lists.where((w) => w.id != e.id).toList();
    emit(state.copyWith(
      lists: updated,
      activeId: state.activeId == e.id
          ? (updated.isNotEmpty ? updated.first.id : null)
          : state.activeId,
      clearActive: updated.isEmpty,
      activeStocks: state.activeId == e.id ? const [] : state.activeStocks,
    ));
  }

  Future<void> _onAdd(
      WatchlistAddStockRequested e, Emitter<WatchlistState> emit) async {
    final list = state.lists.firstWhere(
      (w) => w.id == e.watchlistId,
      orElse: () => const WatchlistModel(id: '', name: '', symbols: []),
    );
    if (list.id.isEmpty) return;

    if (list.symbols.length >= WatchlistState.maxStocksPerList) {
      emit(state.copyWith(error: 'Max ${WatchlistState.maxStocksPerList} stocks per list'));
      return;
    }
    if (list.symbols.contains(e.symbol)) {
      emit(state.copyWith(error: 'Stock already in this watchlist'));
      return;
    }
    final updated = state.lists
        .map((w) => w.id == e.watchlistId
            ? w.copyWith(symbols: [...w.symbols, e.symbol])
            : w)
        .toList();
    final newSymbols = updated
        .firstWhere((w) => w.id == e.watchlistId)
        .symbols;
    final stocks = await _repo.fetchStocks(newSymbols);
    _maybeNotifyForBlowUp(stocks);
    emit(state.copyWith(
      lists: updated,
      activeStocks: state.activeId == e.watchlistId ? stocks : state.activeStocks,
      error: null,
    ));
  }

  Future<void> _onRemove(
      WatchlistRemoveStockRequested e, Emitter<WatchlistState> emit) async {
    final updated = state.lists.map((w) {
      if (w.id != e.watchlistId) return w;
      return w.copyWith(symbols: w.symbols.where((s) => s != e.symbol).toList());
    }).toList();
    final stocks = state.activeStocks.where((s) => s.symbol != e.symbol).toList();
    emit(state.copyWith(
      lists: updated,
      activeStocks: state.activeId == e.watchlistId ? stocks : state.activeStocks,
    ));
  }

  Future<void> _onFetchActive(
      WatchlistActiveStocksRequested e, Emitter<WatchlistState> emit) async {
    final list = state.lists.firstWhere(
      (w) => w.id == e.watchlistId,
      orElse: () => const WatchlistModel(id: '', name: '', symbols: []),
    );
    if (list.id.isEmpty) return;
    final stocks = await _repo.fetchStocks(list.symbols);
    _maybeNotifyForBlowUp(stocks);
    emit(state.copyWith(
      activeId: list.id,
      activeStocks: stocks,
      isLive: _repo.isLive,
      lastUpdated: DateTime.now(),
    ));
  }

  Future<void> _onRefresh(
      WatchlistRefreshRequested e, Emitter<WatchlistState> emit) async {
    _log('WatchlistRefreshRequested');
    if (state.activeId == null) return;
    final list = state.lists.firstWhere((w) => w.id == state.activeId);
    final stocks = await _repo.fetchStocks(list.symbols);
    _maybeNotifyForBlowUp(stocks);
    _log('refreshed: ${stocks.length}/${list.symbols.length} ok');
    emit(state.copyWith(activeStocks: stocks, lastUpdated: DateTime.now()));
  }

  Future<void> _onAutoTick(
      _WatchlistAutoTick e, Emitter<WatchlistState> emit) async {
    final id = state.activeId;
    if (id == null) return;
    final list = state.lists.firstWhere(
      (w) => w.id == id,
      orElse: () => const WatchlistModel(id: '', name: '', symbols: []),
    );
    if (list.id.isEmpty || list.symbols.isEmpty) return;
    final stocks = await _repo.fetchStocks(list.symbols);
    _maybeNotifyForBlowUp(stocks);
    emit(state.copyWith(activeStocks: stocks, lastUpdated: DateTime.now()));
  }
}

class _WatchlistAutoTick extends WatchlistEvent {
  const _WatchlistAutoTick();
}
