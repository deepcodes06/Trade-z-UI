import 'package:equatable/equatable.dart';

class UserProfile extends Equatable {
  final String clientId;
  final String name;
  final String email;
  final String phone;
  final double availableMargin;
  final double usedMargin;
  final String broker;

  const UserProfile({
    required this.clientId,
    required this.name,
    required this.email,
    required this.phone,
    required this.availableMargin,
    required this.usedMargin,
    required this.broker,
  });

  double get totalMargin => availableMargin + usedMargin;

  @override
  List<Object?> get props =>
      [clientId, name, email, phone, availableMargin, usedMargin, broker];
}
