import 'package:equatable/equatable.dart';

class IndexModel extends Equatable {
  final String symbol;
  final String name;
  final double last;
  final double change;
  final double percentChange;

  const IndexModel({
    required this.symbol,
    required this.name,
    required this.last,
    required this.change,
    required this.percentChange,
  });

  bool get isUp => change >= 0;

  @override
  List<Object?> get props => [symbol, name, last, change, percentChange];
}
