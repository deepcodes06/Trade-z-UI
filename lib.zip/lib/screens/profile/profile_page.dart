import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../backend/bloc/auth/auth_bloc.dart';
import '../../backend/bloc/auth/auth_event.dart';
import '../../backend/bloc/profile/profile_bloc.dart';
import '../../backend/bloc/profile/profile_event.dart';
import '../../backend/bloc/profile/profile_state.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_responsive.dart';

class ProfilePage extends StatefulWidget {
  final VoidCallback onSearchTap;

  const ProfilePage({super.key, required this.onSearchTap});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ProfileBloc>().add(const ProfileLoadRequested());
    });
  }

  @override
  Widget build(BuildContext context) {
    AppResponsive.init(context);
    return BlocBuilder<ProfileBloc, ProfileState>(
      builder: (context, state) {
        if (state.status == ProfileStatus.loading || state.profile == null) {
          return Center(child: CircularProgressIndicator(color: AppPalette.of(context).primary));
        }
        final p = state.profile!;
        return ListView(
          padding: EdgeInsets.only(bottom: AppResponsive.h(24)),
          children: [
            SizedBox(height: AppResponsive.h(8)),
            _HeaderCard(),
            SizedBox(height: AppResponsive.h(14)),
            _Section(
              title: 'FUNDS',
              child: Column(
                children: [
                  _Row(label: 'Available margin', value: '₹ ${p.availableMargin.toStringAsFixed(2)}'),
                  _Divider(),
                  _Row(label: 'Used margin', value: '₹ ${p.usedMargin.toStringAsFixed(2)}'),
                  _Divider(),
                  _Row(label: 'Total', value: '₹ ${p.totalMargin.toStringAsFixed(2)}', highlight: true),
                ],
              ),
            ),
            _Section(
              title: 'ACCOUNT',
              child: Column(
                children: [
                  _Row(label: 'Client ID', value: p.clientId),
                  _Divider(),
                  _Row(label: 'Broker', value: p.broker),
                  _Divider(),
                  _Row(label: 'Name', value: p.name),
                  _Divider(),
                  _Row(label: 'Email', value: p.email),
                  _Divider(),
                  _Row(label: 'Phone', value: p.phone),
                ],
              ),
            ),
            _Section(
              title: 'TOOLS',
              child: Column(
                children: [
                  _Tile(icon: Icons.notifications_outlined, title: 'Blow-up alerts', trailing: Switch(value: true, onChanged: (_) {})),
                  _Divider(),
                  _Tile(icon: Icons.lock_outline, title: 'Change PIN'),
                  _Divider(),
                  _Tile(icon: Icons.fingerprint, title: 'Biometric login', trailing: Switch(value: false, onChanged: (_) {})),
                  _Divider(),
                  _Tile(icon: Icons.cloud_download_outlined, title: 'Reports'),
                  _Divider(),
                  _Tile(icon: Icons.support_agent, title: 'Support'),
                  _Divider(),
                  _Tile(
                    icon: Icons.logout,
                    title: 'Logout',
                    color: AppPalette.of(context).loss,
                    onTap: () {
                      context.read<AuthBloc>().add(const AuthLogoutRequested());
                      context.read<ProfileBloc>().add(const ProfileLogoutRequested());
                    },
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}

class _HeaderCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    return BlocBuilder<ProfileBloc, ProfileState>(
      builder: (_, state) {
        final name = state.profile?.name ?? '';
        final initials = name.isEmpty
            ? 'U'
            : name.split(' ').where((s) => s.isNotEmpty).map((s) => s[0].toUpperCase()).take(2).join();
        return Container(
          margin: AppResponsive.symH(16).add(EdgeInsets.only(top: AppResponsive.h(8))),
          padding: AppResponsive.padAll(18),
          decoration: BoxDecoration(
            color: const Color(0xADFFFFFF), // rgba(255,255,255,0.68)
            borderRadius: BorderRadius.circular(AppResponsive.w(20)),
            border: Border.all(
              color: const Color(0xD9FFFFFF), // rgba(255,255,255,0.85)
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0x0F1E2D3C), // rgba(30,45,60,0.06)
                blurRadius: 24,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: AppResponsive.w(56),
                height: AppResponsive.w(56),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: p.primary,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(color: p.primary.withValues(alpha: 0.25), blurRadius: 16, offset: const Offset(0, 4)),
                  ],
                ),
                child: Text(
                  initials,
                  style: GoogleFonts.spaceGrotesk(
                    color: p.onPrimary,
                    fontSize: AppResponsive.font(20),
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
              SizedBox(width: AppResponsive.w(14)),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: GoogleFonts.spaceGrotesk(
                        color: p.textPrimary,
                        fontSize: AppResponsive.font(18),
                        fontWeight: FontWeight.w700,
                        letterSpacing: -0.2,
                      ),
                    ),
                    SizedBox(height: AppResponsive.h(3)),
                    Text(
                      state.profile?.clientId ?? '',
                      style: GoogleFonts.inter(
                        color: p.textSecondary,
                        fontSize: AppResponsive.font(12),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.qr_code, color: p.primary, size: AppResponsive.w(28)),
            ],
          ),
        );
      },
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  final Widget child;
  const _Section({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    return Container(
      margin: AppResponsive.symH(16).add(EdgeInsets.only(top: AppResponsive.h(10))),
      decoration: GlassCard.of(context, radius: AppResponsive.w(16)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: AppResponsive.symH(16).add(EdgeInsets.only(top: AppResponsive.h(14), bottom: AppResponsive.h(4))),
            child: Text(
              title,
              style: GoogleFonts.inter(color: p.textMuted, fontSize: AppResponsive.font(11), fontWeight: FontWeight.w700, letterSpacing: 1.1),
            ),
          ),
          Padding(
            padding: AppResponsive.symH(16).add(EdgeInsets.symmetric(vertical: AppResponsive.h(6))),
            child: child,
          ),
        ],
      ),
    );
  }
}

class _Row extends StatelessWidget {
  final String label;
  final String value;
  final bool highlight;
  const _Row({required this.label, required this.value, this.highlight = false});

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    return Padding(
      padding: EdgeInsets.symmetric(vertical: AppResponsive.h(10)),
      child: Row(
        children: [
          Expanded(child: Text(label, style: GoogleFonts.inter(color: p.textSecondary, fontSize: AppResponsive.font(13), fontWeight: FontWeight.w500))),
          Text(value, style: GoogleFonts.inter(color: p.textPrimary, fontSize: AppResponsive.font(highlight ? 14 : 13), fontWeight: highlight ? FontWeight.w700 : FontWeight.w600, letterSpacing: -0.1)),
        ],
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  final IconData icon;
  final String title;
  final Widget? trailing;
  final Color? color;
  final VoidCallback? onTap;

  const _Tile({required this.icon, required this.title, this.trailing, this.color, this.onTap});

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    final c = color ?? p.textPrimary;
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: AppResponsive.h(12)),
        child: Row(
          children: [
            Container(
              width: AppResponsive.w(36),
              height: AppResponsive.w(36),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: p.softHighlight,
                borderRadius: BorderRadius.circular(AppResponsive.w(10)),
                border: Border.all(color: p.primary.withValues(alpha: 0.15), width: 0.8),
              ),
              child: Icon(icon, color: c, size: AppResponsive.w(18)),
            ),
            SizedBox(width: AppResponsive.w(12)),
            Expanded(child: Text(title, style: GoogleFonts.inter(color: c, fontSize: AppResponsive.font(14), fontWeight: FontWeight.w600))),
            // ignore: use_null_aware_elements
            if (trailing != null) trailing!,
            if (trailing == null) Icon(Icons.chevron_right, color: p.textMuted, size: AppResponsive.w(20)),
          ],
        ),
      ),
    );
  }
}

class _Divider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(height: 1, color: AppPalette.of(context).divider);
  }
}
